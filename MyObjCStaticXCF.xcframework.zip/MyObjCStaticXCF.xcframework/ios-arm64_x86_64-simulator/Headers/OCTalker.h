//
//  OCTalker.h
//  OCTalker
//
//  Created by David Wagner on 09/04/2022.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface OCTalker : NSObject

- (NSString *)say:(NSString *)something;

@end

NS_ASSUME_NONNULL_END
